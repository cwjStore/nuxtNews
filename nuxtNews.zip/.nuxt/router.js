import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _48078916 = () => interopDefault(import('..\\pages\\inland\\index.vue' /* webpackChunkName: "pages/inland/index" */))
const _2515f140 = () => interopDefault(import('..\\pages\\international\\index.vue' /* webpackChunkName: "pages/international/index" */))
const _a02c2d0e = () => interopDefault(import('..\\pages\\military\\index.vue' /* webpackChunkName: "pages/military/index" */))
const _5dc0df58 = () => interopDefault(import('..\\pages\\recreation\\index.vue' /* webpackChunkName: "pages/recreation/index" */))
const _424103f4 = () => interopDefault(import('..\\pages\\society\\index.vue' /* webpackChunkName: "pages/society/index" */))
const _49956ac7 = () => interopDefault(import('..\\pages\\sports\\index.vue' /* webpackChunkName: "pages/sports/index" */))
const _4f6fc1b4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/inland",
    component: _48078916,
    name: "inland"
  }, {
    path: "/international",
    component: _2515f140,
    name: "international"
  }, {
    path: "/military",
    component: _a02c2d0e,
    name: "military"
  }, {
    path: "/recreation",
    component: _5dc0df58,
    name: "recreation"
  }, {
    path: "/society",
    component: _424103f4,
    name: "society"
  }, {
    path: "/sports",
    component: _49956ac7,
    name: "sports"
  }, {
    path: "/",
    component: _4f6fc1b4,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
