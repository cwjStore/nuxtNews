export { default as Card } from '../..\\components\\card\\index.vue'
export { default as Header } from '../..\\components\\header\\index.vue'
export { default as Tabs } from '../..\\components\\tabs\\index.vue'

export const LazyCard = import('../..\\components\\card\\index.vue' /* webpackChunkName: "components_card/index" */).then(c => c.default || c)
export const LazyHeader = import('../..\\components\\header\\index.vue' /* webpackChunkName: "components_header/index" */).then(c => c.default || c)
export const LazyTabs = import('../..\\components\\tabs\\index.vue' /* webpackChunkName: "components_tabs/index" */).then(c => c.default || c)
